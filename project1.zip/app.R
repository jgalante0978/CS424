library(shiny)
library(shinydashboard)
library(ggplot2)
library(lubridate)
library(DT)
library(jpeg)
library(leaflet)

choleraDeathsTable <- read.table(file = "choleraDeaths.tsv", sep = "\t", header = TRUE)

naplesCholeraAgeSexData <- read.table(file = "naplesCholeraAgeSexData2.tsv", sep = "\t", header = TRUE)

ui <- dashboardPage(
  dashboardHeader(title = "Project 1"),
  dashboardSidebar(),
  dashboardBody(
    fluidRow(
      #displaying the table and line chart for choleraDeaths.tsv
      box(title = "Cholera Deaths and Attacks Table", DT::dataTableOutput("choleraTable")),
      box(title = "Line Chart of Attacks and Deaths", plotOutput("dotPlot"))
    ),
    fluidRow(
      #displaying the table and bar graph for naplesCholeraAgeSexData2.tsv
      box(title = "Table of Age and Gender", DT::dataTableOutput("naplesCholeraTable")),
      box(title = "Bar Chart of Gender and Age of Death", plotOutput("naplesCholeraBarChart"))
    )
  )
)

server <- function(input, output) {

  output$naplesCholeraTable <- DT::renderDataTable({
    #reads in the naples cholera age and gender file
    naplesCholeraAgeSexData <- read.table(file = "naplesCholeraAgeSexData2.tsv", sep = "\t", header = TRUE)
  })
  
  output$choleraTable <- DT::renderDataTable({
    #reads in the cholera deaths tsv file
    choleraDeathsTable <- read.table(file = "choleraDeaths.tsv", sep = "\t", header = TRUE)
  })
  
  output$dotPlot <- renderPlot({
    #plots the cholera deaths table
    ggplot(choleraDeathsTable, aes(x = choleraDeathsTable$Date, y = choleraDeathsTable$Attack)) + geom_point() + labs(x = "Date", y = "Attacks, Deaths") + geom_line(aes(group=1)) + geom_line(aes(group=2))
    
  })
  
  output$naplesCholeraBarChart <- renderPlot({
    #plots the bar graph of age ranges in males for cholera deaths
    ggplot(naplesCholeraAgeSexData, aes(naplesCholeraAgeSexData$age, naplesCholeraAgeSexData$male)) + geom_bar(stat = "identity")
  })
  
  
  
}

shinyApp(ui = ui, server = server)